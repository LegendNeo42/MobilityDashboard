<script lang="ts">
  import VehicleChart from "./VehicleChart.svelte";
</script>

<VehicleChart />

