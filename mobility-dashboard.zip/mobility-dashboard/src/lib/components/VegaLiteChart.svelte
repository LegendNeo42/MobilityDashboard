<script lang="ts">
  import embed from "vega-embed";
  import { changeset } from "vega";

  let {
    spec,
    dataName = "table",
    dataValues = []
  } = $props<{ spec: any; dataName?: string; dataValues?: any[] }>();

  let el: HTMLDivElement | null = null;
  let view: any = null;

  function applyData() {
    if (!view || !dataName) return;
    const cs = changeset().remove(() => true).insert(dataValues ?? []);
    view.change(dataName, cs).runAsync();
  }

  // Embed nur, wenn sich der Spec (Struktur) ändert
  $effect(() => {
    if (!el || !spec) return;

    let cancelled = false;

    (async () => {
      if (view) {
        try { view.finalize(); } catch {}
        view = null;
      }

      const result = await embed(el, spec, { actions: false });
      if (cancelled) return;

      view = result.view;
      applyData(); // initiale Daten setzen
    })();

    return () => {
      cancelled = true;
      if (view) {
        try { view.finalize(); } catch {}
        view = null;
      }
    };
  });

  // Bei Datenwechsel nur Daten updaten (kein Re-Embed)
  $effect(() => {
    applyData();
  });
</script>

<div bind:this={el} style="width: 100%; min-height: 520px;"></div>
