<script lang="ts">
  import { onMount } from "svelte";
  import VegaLiteChart from "./lib/components/VegaLiteChart.svelte";
  import { loadVehicleRows, type VehicleRow } from "./lib/data/vehicle";
  import {
    loadVehicleModalSplitBySemesterTime,
    type VehicleModalSplitRow,
  } from "./lib/data/vehicle";

  let error = $state<string | null>(null);

  let dataBySemester = $state<Map<string, VehicleModalSplitRow[]> | null>(null);
  let semesterOptions = $state<string[]>([]);
  let semesterTime = $state<string>("");

  let sortMode = $state<"fixed" | "frequency">("fixed");

  onMount(async () => {
    try {
      dataBySemester = await loadVehicleModalSplitBySemesterTime();
      semesterOptions = Array.from(dataBySemester.keys()).sort();
      if (!semesterTime && semesterOptions.length > 0)
        semesterTime = semesterOptions[0];
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
  });
  let values = $derived.by(() => {
    if (!dataBySemester || !semesterTime) return [];
    return dataBySemester.get(semesterTime) ?? [];
  });

  let spec = $derived.by((): any => {
    if (!dataBySemester || !semesterTime) return null;


    const ySort =
      sortMode === "frequency"
        ? "-x"
        : { field: "vehicle_order", order: "ascending" };

    return {
      $schema: "https://vega.github.io/schema/vega-lite/v5.json",
      width: "container",
      height: 460,
      autosize: { type: "fit-x", contains: "padding" },
      data: { name: "table" },

      mark: "bar",
      encoding: {
        y: {
          field: "vehicle_label",
          type: "nominal",
          sort: ySort,
          title: "Verkehrsmittel",
        },
        x: {
          field: "count",
          type: "quantitative",
          title: "Anzahl der Nennungen (Hauptverkehrsmittel)",
        },
        tooltip: [
          { field: "vehicle_label", type: "nominal", title: "Verkehrsmittel" },
          { field: "count", type: "quantitative", title: "Anzahl" },
        ],
      },
    };
  });
</script>

{#if error}
  <div class="page">
    <p>Fehler: {error}</p>
  </div>
{:else if !dataBySemester}
  <div class="page">
    <p>Lade Daten…</p>
  </div>
{:else}
  <div class="page">
    <div class="controls">
      <label>
        Semester-Zeit:
        <select bind:value={semesterTime}>
          {#each semesterOptions as opt}
            <option value={opt}>{opt}</option>
          {/each}
        </select>
      </label>

      <label style="margin-left: 12px;">
        Sortierung:
        <select bind:value={sortMode}>
          <option value="fixed">Fixe Reihenfolge</option>
          <option value="frequency">Nach Häufigkeit</option>
        </select>
      </label>
    </div>

    <div class="card">
      <VegaLiteChart {spec} dataName="table" dataValues={values}
      ></VegaLiteChart>
    </div>
  </div>
{/if}

<style>
  .page {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 16px;
  }

  .controls {
    margin-bottom: 12px;
  }

  .card {
    background: white;
    border-radius: 12px;
    padding: 12px;
  }
</style>
